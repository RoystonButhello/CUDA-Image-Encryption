var dir_ff42a09433eb749dc5553c3aaf33faf9 =
[
    [ "Classes.hpp", "Classes_8hpp.html", "Classes_8hpp" ],
    [ "Core.hpp", "Core_8hpp.html", "Core_8hpp" ],
    [ "experiment.cpp", "experiment_8cpp.html", "experiment_8cpp" ],
    [ "kernels.cu", "kernels_8cu.html", null ],
    [ "kernels.hpp", "kernels_8hpp.html", "kernels_8hpp" ],
    [ "Main.cpp", "Main_8cpp.html", "Main_8cpp" ]
];