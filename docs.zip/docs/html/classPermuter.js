var classPermuter =
[
    [ "map", "classPermuter.html#ab15f2574a8b7577e73a46f7dff2698d9", null ],
    [ "x", "classPermuter.html#a02a4355b80f6302fd1a6dbb7a38f9b14", null ],
    [ "y", "classPermuter.html#a89e80fe47468705eab6e052beb1a76c3", null ],
    [ "x_bar", "classPermuter.html#ab197f2e3f8b77503a0583167d1faf241", null ],
    [ "y_bar", "classPermuter.html#a33f32379731d5ae43dcfc5c5fedbe421", null ],
    [ "alpha", "classPermuter.html#aa4c5ad7b4fb7baedaf02d770d8fb4028", null ],
    [ "beta", "classPermuter.html#a1e8ccc269d80b4caa77fbb8343e0bd22", null ],
    [ "myu", "classPermuter.html#ae2787f7a2cf298d43e2c40d6a5602e85", null ],
    [ "r", "classPermuter.html#a551dacc8cd78377951ce6137013010aa", null ]
];