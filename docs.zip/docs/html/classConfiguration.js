var classConfiguration =
[
    [ "rounds", "classConfiguration.html#ab590dd51590ebadd20df0a3e39a9bfa9", null ],
    [ "rotations", "classConfiguration.html#a7e51747c444d2c36071f461bc2b0dd65", null ]
];