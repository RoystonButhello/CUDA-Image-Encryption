var kernels_8hpp =
[
    [ "kernel_WarmUp", "kernels_8hpp.html#a654c7e29588dd0477944528926b332dc", null ],
    [ "Wrap_RotatePerm", "kernels_8hpp.html#a088f82f6fa12c9bffa918e9de169a054", null ],
    [ "Wrap_Diffusion", "kernels_8hpp.html#aac4fa60c574a6abadd23329807ed8887", null ],
    [ "Wrap_imageSumReduce", "kernels_8hpp.html#a0f64bcf42c91b00b8ee36af7ce3ba523", null ]
];