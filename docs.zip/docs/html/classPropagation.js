var classPropagation =
[
    [ "permute_propagation_factor", "classPropagation.html#a5a3d808d9d9c246774e3fc46adfdebe3", null ],
    [ "diffuse_propagation_factor", "classPropagation.html#aeb0cbc2df26f4273b3490ad917de2acb", null ]
];