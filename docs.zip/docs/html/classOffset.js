var classOffset =
[
    [ "permute_param_modifier", "classOffset.html#acaee8a7b090ed9023d1f420b343bdd6e", null ],
    [ "diffuse_param_modifier", "classOffset.html#a3d6aca4a5b3a183e25349434c8292219", null ],
    [ "permute_param_offset", "classOffset.html#a2e1637aa6e8c0079e552c1527b2a30c2", null ],
    [ "diffuse_param_offset", "classOffset.html#accc4cda27f1bef538cdb2ee7099279fe", null ]
];