var classDiffuser =
[
    [ "map", "classDiffuser.html#adc839fd78f6168fe3dc170532d1f834a", null ],
    [ "x", "classDiffuser.html#a9bb0e67b9ed0db5a49d1a34ac618b003", null ],
    [ "y", "classDiffuser.html#a9f8afcde863463ec34dcbeeb515974e9", null ],
    [ "x_bar", "classDiffuser.html#a7c4e492a4ff7631c87e4fabc3466feba", null ],
    [ "y_bar", "classDiffuser.html#a445b6d2ae6ec9c95a72eb39f273a65de", null ],
    [ "alpha", "classDiffuser.html#a749ab3638bd753dae15e54eae45fab16", null ],
    [ "beta", "classDiffuser.html#a9e8319552785ad429d108f3f5a202247", null ],
    [ "myu", "classDiffuser.html#ae29f2581bfdf5a542efbdb24d5aa23e8", null ],
    [ "r", "classDiffuser.html#ac00a0301b4bb96ab039f97ae9ddfbca7", null ]
];