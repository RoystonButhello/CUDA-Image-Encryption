var searchData=
[
  ['kernel_5fwarmup',['kernel_WarmUp',['../kernels_8hpp.html#a654c7e29588dd0477944528926b332dc',1,'kernels.hpp']]]
];
