var searchData=
[
  ['wrap_5fdiffusion',['Wrap_Diffusion',['../kernels_8hpp.html#aac4fa60c574a6abadd23329807ed8887',1,'kernels.hpp']]],
  ['wrap_5fimagesumreduce',['Wrap_imageSumReduce',['../kernels_8hpp.html#a0f64bcf42c91b00b8ee36af7ce3ba523',1,'kernels.hpp']]],
  ['wrap_5frotateperm',['Wrap_RotatePerm',['../kernels_8hpp.html#a088f82f6fa12c9bffa918e9de169a054',1,'kernels.hpp']]]
];
