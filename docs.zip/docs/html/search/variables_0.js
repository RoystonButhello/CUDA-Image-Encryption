var searchData=
[
  ['alpha',['alpha',['../classPermuter.html#aa4c5ad7b4fb7baedaf02d770d8fb4028',1,'Permuter::alpha()'],['../classDiffuser.html#a749ab3638bd753dae15e54eae45fab16',1,'Diffuser::alpha()'],['../classCRNG.html#adce41afbd217e9e131b63cbeac60ccbf',1,'CRNG::ALPHA()']]]
];
