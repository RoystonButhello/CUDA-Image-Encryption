var searchData=
[
  ['type',['type',['../classPaths.html#abc84972f3e98034fd3683883718396df',1,'Paths']]]
];
