var searchData=
[
  ['r',['r',['../classPermuter.html#a551dacc8cd78377951ce6137013010aa',1,'Permuter::r()'],['../classDiffuser.html#ac00a0301b4bb96ab039f97ae9ddfbca7',1,'Diffuser::r()'],['../classCRNG.html#a1a0b73e361c01d6fd3c59818ee9e99a7',1,'CRNG::R()']]],
  ['random_5fnumber',['RANDOM_NUMBER',['../classCRNG.html#aeac42e811b8de22b8f8ff60fd00814ac',1,'CRNG']]],
  ['randomnumber',['randomNumber',['../Classes_8hpp.html#ae7686b9cdb0eabcb32ab551bdd41af00',1,'Classes.hpp']]],
  ['rotations',['rotations',['../classConfiguration.html#a7e51747c444d2c36071f461bc2b0dd65',1,'Configuration']]],
  ['rounds',['rounds',['../classConfiguration.html#ab590dd51590ebadd20df0a3e39a9bfa9',1,'Configuration']]]
];
