var searchData=
[
  ['alpha_5flower_5flimit',['ALPHA_LOWER_LIMIT',['../Core_8hpp.html#a19fe00980834896c346afcdf0d28e2fb',1,'Core.hpp']]],
  ['alpha_5fupper_5flimit',['ALPHA_UPPER_LIMIT',['../Core_8hpp.html#a129c931008134ba03305bfb71349ea84',1,'Core.hpp']]]
];
