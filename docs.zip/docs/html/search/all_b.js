var searchData=
[
  ['offset',['Offset',['../classOffset.html',1,'Offset'],['../Classes_8hpp.html#adc97734c3146947e87902755f386597d',1,'offset():&#160;Classes.hpp']]]
];
