var searchData=
[
  ['beta_5flower_5flimit',['BETA_LOWER_LIMIT',['../Core_8hpp.html#a13e0254bd983611c5068e6f87e788113',1,'Core.hpp']]],
  ['beta_5fupper_5flimit',['BETA_UPPER_LIMIT',['../Core_8hpp.html#a68a64abf05b62fdce19c42e0595b91ed',1,'Core.hpp']]]
];
