var searchData=
[
  ['r',['r',['../classPermuter.html#a551dacc8cd78377951ce6137013010aa',1,'Permuter::r()'],['../classDiffuser.html#ac00a0301b4bb96ab039f97ae9ddfbca7',1,'Diffuser::r()'],['../classCRNG.html#a1a0b73e361c01d6fd3c59818ee9e99a7',1,'CRNG::R()']]],
  ['r_5flower_5flimit',['R_LOWER_LIMIT',['../Core_8hpp.html#abc534c81dcb62466c616dafd079659b5',1,'Core.hpp']]],
  ['r_5fupper_5flimit',['R_UPPER_LIMIT',['../Core_8hpp.html#a2717df063334ebb93a0e8476bcc26c63',1,'Core.hpp']]],
  ['random',['Random',['../classRandom.html',1,'']]],
  ['random_5fnumber',['RANDOM_NUMBER',['../classCRNG.html#aeac42e811b8de22b8f8ff60fd00814ac',1,'CRNG']]],
  ['randomnumber',['randomNumber',['../Classes_8hpp.html#ae7686b9cdb0eabcb32ab551bdd41af00',1,'Classes.hpp']]],
  ['reversechangepropagation',['reverseChangePropagation',['../Core_8hpp.html#a1888b7e2478fd74667ff66147c6ac313',1,'Core.hpp']]],
  ['rotations',['rotations',['../classConfiguration.html#a7e51747c444d2c36071f461bc2b0dd65',1,'Configuration']]],
  ['rounds',['rounds',['../classConfiguration.html#ab590dd51590ebadd20df0a3e39a9bfa9',1,'Configuration']]]
];
