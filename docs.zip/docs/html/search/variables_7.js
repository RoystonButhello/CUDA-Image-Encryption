var searchData=
[
  ['offset',['offset',['../Classes_8hpp.html#adc97734c3146947e87902755f386597d',1,'Classes.hpp']]]
];
