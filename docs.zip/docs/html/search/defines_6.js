var searchData=
[
  ['x_5flower_5flimit',['X_LOWER_LIMIT',['../Core_8hpp.html#a9e9b043ac37f2a383a98a760ed2ef306',1,'Core.hpp']]],
  ['x_5fupper_5flimit',['X_UPPER_LIMIT',['../Core_8hpp.html#a3cfdb442fbca28aba28ea1a6602da9c1',1,'Core.hpp']]]
];
