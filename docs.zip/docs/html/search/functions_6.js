var searchData=
[
  ['initialize',['Initialize',['../Core_8hpp.html#aec9c509cda8801dc8be914f9dbc9d57e',1,'Core.hpp']]]
];
