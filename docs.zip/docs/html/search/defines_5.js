var searchData=
[
  ['r_5flower_5flimit',['R_LOWER_LIMIT',['../Core_8hpp.html#abc534c81dcb62466c616dafd079659b5',1,'Core.hpp']]],
  ['r_5fupper_5flimit',['R_UPPER_LIMIT',['../Core_8hpp.html#a2717df063334ebb93a0e8476bcc26c63',1,'Core.hpp']]]
];
