var searchData=
[
  ['beta',['BETA',['../classCRNG.html#a9a6167ed077a4246dc7e11c5ec7ea9eb',1,'CRNG::BETA()'],['../classPermuter.html#a1e8ccc269d80b4caa77fbb8343e0bd22',1,'Permuter::beta()'],['../classDiffuser.html#a9e8319552785ad429d108f3f5a202247',1,'Diffuser::beta()']]]
];
